├── bin
|   ├── config
│   │   ├── README.md
│   │   ├── bin-config.json
│   │   ├── misc-config.json
│   │   ├── custom-config.json
│   │   └── repos.json
│   ├── data
│   │   ├── README.md
│   │   ├── TO-DO.md
│   │   └── X.sh
│   ├── Custom
│   │   ├── README.md
│   │   ├── c1.sh
│   │   ├── c2.sh
│   │   ├── c3.sh
│   │   └── c4.sh
│   ├── Misc
│   │   ├── README.md
│   │   ├── 1.sh
│   │   ├── 2.sh
│   │   ├── 3.sh
│   │   └── 4.sh
│   ├── Addons
│   │   ├── <Dir_name_1>
│   │   └── exec.sh
│   │   ├── <Dir_name_2>
│   │   └── exec.sh
│   └── main.sh
└──/
